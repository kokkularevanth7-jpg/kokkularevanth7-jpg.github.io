REVANTH PORTFOLIO

1. Replace YOUR_EMAIL@example.com in index.html with your email.
2. Replace YOUR_GITHUB_USERNAME with your GitHub username.
3. Put your resume PDF in this folder and name it: resume.pdf
4. Open index.html to preview the website.
5. To publish free with GitHub Pages:
   - Create a GitHub repository named yourusername.github.io
   - Upload index.html, style.css, script.js and resume.pdf
   - In GitHub: Settings -> Pages -> Deploy from branch -> main/root.
6. Your portfolio URL will be:
   https://yourusername.github.io/
